const express = require("express");
const http = require("http");
const mongoose = require("mongoose");
const socketIo = require("socket.io");
const multer = require("multer");
const cors = require("cors");

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.json());
app.use(cors());
app.use(express.static("public"));

mongoose.connect("mongodb://127.0.0.1:27017/social");

const Post = mongoose.model("Post", {
  user: String,
  content: String,
  image: String,
  likes: [String],
  comments: [{ user: String, text: String }]
});

const storage = multer.diskStorage({
  destination: "public/uploads",
  filename: (req, file, cb) => cb(null, Date.now() + file.originalname)
});
const upload = multer({ storage });

app.post("/post", upload.single("image"), async (req, res) => {
  const post = new Post({
    user: req.body.user,
    content: req.body.content,
    image: req.file ? req.file.filename : ""
  });
  await post.save();
  io.emit("newPost", post);
  res.send(post);
});

app.get("/posts", async (req, res) => {
  const posts = await Post.find();
  res.send(posts);
});

app.post("/like/:id", async (req, res) => {
  const post = await Post.findById(req.params.id);
  post.likes.push(req.body.user);
  await post.save();
  io.emit("updatePost", post);
  res.send(post);
});

app.post("/comment/:id", async (req, res) => {
  const post = await Post.findById(req.params.id);
  post.comments.push({ user: req.body.user, text: req.body.text });
  await post.save();
  io.emit("updatePost", post);
  res.send(post);
});

io.on("connection", socket => {
  console.log("User connected");
});

server.listen(3000, () => console.log("Server running on http://localhost:3000"));
