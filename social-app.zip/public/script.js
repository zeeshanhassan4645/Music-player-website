const socket = io();
const feed = document.getElementById("feed");

function loadPosts() {
  fetch("/posts")
    .then(res => res.json())
    .then(posts => {
      feed.innerHTML = "";
      posts.forEach(showPost);
    });
}

function showPost(post) {
  const div = document.createElement("div");
  div.innerHTML = `
    <h4>${post.user}</h4>
    <p>${post.content}</p>
    ${post.image ? `<img src="uploads/${post.image}" width="200">` : ""}
    <p>Likes: ${post.likes.length}</p>
    <button onclick="likePost('${post._id}')">Like</button>

    <input placeholder="Comment" id="c${post._id}">
    <button onclick="commentPost('${post._id}')">Comment</button>

    <div>${post.comments.map(c => `<p>${c.user}: ${c.text}</p>`).join("")}</div>
  `;
  feed.appendChild(div);
}

function createPost() {
  const user = document.getElementById("username").value;
  const content = document.getElementById("content").value;
  const image = document.getElementById("image").files[0];

  const formData = new FormData();
  formData.append("user", user);
  formData.append("content", content);
  formData.append("image", image);

  fetch("/post", { method: "POST", body: formData });
}

function likePost(id) {
  fetch("/like/" + id, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user: document.getElementById("username").value })
  });
}

function commentPost(id) {
  const text = document.getElementById("c" + id).value;
  fetch("/comment/" + id, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      user: document.getElementById("username").value,
      text
    })
  });
}

socket.on("newPost", loadPosts);
socket.on("updatePost", loadPosts);

loadPosts();
