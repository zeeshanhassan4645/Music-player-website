const songs = [
  {
    name: "Chill Beat",
    file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    cover: "https://picsum.photos/300?random=1"
  },
  {
    name: "Relax Music",
    file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    cover: "https://picsum.photos/300?random=2"
  },
  {
    name: "Focus Track",
    file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    cover: "https://picsum.photos/300?random=3"
  }
];

const audio = document.getElementById("audio");
const playlist = document.getElementById("playlist");
const title = document.getElementById("title");
const cover = document.getElementById("cover");
const progress = document.getElementById("progress");
const volume = document.getElementById("volume");
const playBtn = document.getElementById("playBtn");

let currentSong = 0;

songs.forEach((song, index) => {
  const li = document.createElement("li");
  li.textContent = song.name;
  li.onclick = () => playSong(index);
  playlist.appendChild(li);
});

function playSong(index) {
  currentSong = index;
  audio.src = songs[index].file;
  title.textContent = songs[index].name;
  cover.src = songs[index].cover;
  audio.play();
  playBtn.textContent = "⏸";
}

function playPause() {
  if (audio.paused) {
    audio.play();
    playBtn.textContent = "⏸";
  } else {
    audio.pause();
    playBtn.textContent = "▶";
  }
}

function nextSong() {
  currentSong = (currentSong + 1) % songs.length;
  playSong(currentSong);
}

function prevSong() {
  currentSong = (currentSong - 1 + songs.length) % songs.length;
  playSong(currentSong);
}

audio.addEventListener("timeupdate", () => {
  progress.value = (audio.currentTime / audio.duration) * 100;
});

progress.addEventListener("input", () => {
  audio.currentTime = (progress.value / 100) * audio.duration;
});

volume.addEventListener("input", () => {
  audio.volume = volume.value;
});

audio.addEventListener("ended", nextSong);
